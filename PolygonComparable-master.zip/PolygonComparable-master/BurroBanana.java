public class BurroBanana extends Banana {
    public BurroBanana() {
        super("Burro Banana", 80);
    }
}