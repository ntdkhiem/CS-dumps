public class FujiApple extends Apple {
    public FujiApple() {
        super("Fuji Apple", 77);
    }
}