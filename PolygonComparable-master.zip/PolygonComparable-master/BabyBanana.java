public class BabyBanana extends Banana {
    public BabyBanana() {
        super("Baby Banana", 72);
    }
}