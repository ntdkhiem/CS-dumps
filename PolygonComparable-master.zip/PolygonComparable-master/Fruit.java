public interface Fruit {
    abstract String getType();
    abstract double getCalories();
    abstract String getCategory();
}