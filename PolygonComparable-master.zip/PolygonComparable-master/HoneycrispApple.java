public class HoneycrispApple extends Apple {
    public HoneycrispApple() {
        super("Honeycrisp Apple", 77);
    }
}