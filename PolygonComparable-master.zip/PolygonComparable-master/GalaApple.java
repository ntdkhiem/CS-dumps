public class GalaApple extends Apple {
    public GalaApple() {
        super("Gala Apple", 77);
    }
}