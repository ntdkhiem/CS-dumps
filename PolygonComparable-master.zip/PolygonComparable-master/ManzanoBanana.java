public class ManzanoBanana extends Banana {
    public ManzanoBanana() {
        super("Manzano Banana", 107);
    }
}